
import re


text=" please provide your mobile number my mobile 45125 number is 8796 928 952"
x =re.findall( "\w{4} \w{3} \w{3}", text)
print (x)

