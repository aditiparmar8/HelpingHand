def SpeechToText():
    import speech_recognition as sr
    r = sr.Recognizer()
    harvard = sr.AudioFile(r"C:\Users\Girish\Downloads\2019_08_23_18_03_22.flac")
    with harvard as source:
        audio = r.record(source)
    value = r.recognize_google(audio)
    return value
print(SpeechToText())
