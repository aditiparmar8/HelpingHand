# python script for sending message update 

import time 
from time import sleep 
from sinchsms import SinchSMS 

# function for sending SMS 
def sendSMS(): 

	# enter all the details 
	# get app_key and app_secret by registering 
	# a app on sinchSMS 
	number = '+918796928952'
	app_key = 'M4FA3IXZ23A4YH0DH5N3Y2FUMACVPPYK'
	app_secret = 'H6NHCEDI3E487K66'

	# enter the message to be sent 
	message = 'Hello Message!!!'

	client = SinchSMS(app_key, app_secret) 
	print("Sending '%s' to %s" % (message, number)) 

	response = client.send_message(number, message) 

if __name__ == "__main__":
    sendSMS() 
