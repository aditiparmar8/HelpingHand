from nltk import word_tokenize, pos_tag, ne_chunk
from nltk import Tree
import pgeocode
import re
import nltk
from nltk.corpus import stopwords
stop = stopwords.words('english')

def get_continuous_chunks(text, label):
    chunked = ne_chunk(pos_tag(word_tokenize(text)))
    prev = None
    continuous_chunk = []
    current_chunk = []

    for subtree in chunked:
        if type(subtree) == Tree and subtree.label() == label:
            current_chunk.append(" ".join([token for token, pos in subtree.leaves()]))
        elif current_chunk:
            named_entity = " ".join(current_chunk)
            if named_entity not in continuous_chunk:
                continuous_chunk.append(named_entity)
                current_chunk = []
        else:
            continue

    return continuous_chunk

def getMobileNumber(text):
    current_chunk = ""
    for word in text.split():
         if len(word) == 10 and word.isdigit():
              current_chunk=word  
    return current_chunk

def getPinCode(text):
    current_chunk = ""
    for word in text.split():
         if len(word) == 6 and word.isdigit():
              current_chunk=word
        
    return current_chunk

def getDisatnce(po1,po2):
    outvalue = 0
    dist=pgeocode.GeoDistance("IN")
    outvalue = int(dist.query_postal_code(po1,po2))
    return outvalue


